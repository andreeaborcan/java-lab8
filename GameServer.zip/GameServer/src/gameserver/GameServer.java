/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameserver;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

/**
 *
 * @author ada
 */
public class GameServer {

    private static final int PORT = 8100;
    private ServerSocket serverSocket;
    private boolean running = false;
    ArrayList <ClientThread> listaClienti=new ArrayList<>();
    public GameServer() throws IOException {
        ServerSocket serverSocket = null;
        
    }

    public static void main(String[] args) throws IOException {
        GameServer server = new GameServer();
        server.init();
        server.waitForClients(); //... handle the exceptions!
    }
    // Implement the init() method: create the serverSocket and set running to true
    // Implement the waitForClients() method: while running is true, create a new socket for every incoming client and start a ClientThread to execute its request.

    public void stop() throws IOException {
        this.running = false;
        serverSocket.close();
    }

    private void init() throws IOException {
         serverSocket = new ServerSocket(PORT);
         running=true;
    }

    private void waitForClients() throws IOException {
        try {
            while (running) {
                System.out.println("Waiting for a client ...");
                Socket socket = serverSocket.accept();
                listaClienti.add( new ClientThread(socket));
                new ClientThread(socket).start();
            }
        } catch (IOException e) {
            System.err.println("Ooops... " + e);
        } finally {
            serverSocket.close();
        }
    }
}
