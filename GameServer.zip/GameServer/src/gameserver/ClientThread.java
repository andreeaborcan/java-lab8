/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameserver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

/**
 *
 * @author ada
 */
class ClientThread extends Thread {

    private Socket socket = null;
    //private final GameServer server;

    public ClientThread(Socket socket) throws IOException {
        this.socket = socket;
       // this.server = new GameServer();
    }

    @Override
    public void run() {
        try {// Get the request from the input stream: client → server
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String request = in.readLine(); // Send the response to the oputput stream: server → client
            String response = execute(request);
            PrintWriter out = new PrintWriter(socket.getOutputStream());
            out.println(response);
            out.flush();
        } catch (IOException e) {
            System.err.println("Communication error... " + e);
        } finally {
            try {
                socket.close(); // or use try-with-resources
            } catch (IOException e) {
                System.err.println(e);
            }
        }
    }

    private String execute(String request) {
        String response;
        response = null;
        if (request.compareToIgnoreCase("start") == 0) {
            response = "Jocul va incepe acum";

        } else {
            response = "Bine ai venit!";
        }
        return response;

    }
}
